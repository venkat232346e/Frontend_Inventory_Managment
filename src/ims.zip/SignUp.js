import React, { useState } from 'react';
import image1 from './images/image1.jpg';

const SignUp = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
  };

  return (
    <div style={styles.container}>
      {/* Left Side: Sign-up Form */}
      <div style={styles.formContainer}>
        <h2>Sign Up For Free.</h2>
        <form onSubmit={handleSubmit}>
          <div style={styles.inputGroup}>
            <input
              type="text"
              name="fullName"
              placeholder="Full Name"
              value={formData.fullName}
              onChange={handleChange}
              required
              style={styles.input}
            />
          </div>
          <div style={styles.inputGroup}>
            <input
              type="email"
              name="email"
              placeholder="Email Address"
              value={formData.email}
              onChange={handleChange}
              required
              style={styles.input}
            />
          </div>
          <div style={styles.inputGroup}>
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
              required
              style={styles.input}
            />
          </div>
          <button type="submit" style={styles.submitButton}>
            Sign Up
          </button>
        </form>
        <div style={styles.footer}>
          <p>
            Already have an account?{' '}
            <a href="/" style={styles.signInLink}>
              Sign In
            </a>
          </p>
        </div>
        <div style={styles.googleSignUp}>
          <button style={styles.googleButton}>
            Sign Up With Google
          </button>
        </div>
      </div>

      {/* Right Side: Inventory Management and Image */}
      <div style={styles.rightContainer}>
        <h2>Inventory Management System</h2>
        <div style={styles.imageContainer}>
          <img src={image1} alt='Inventory' style={styles.image} />
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'space-between',
    height: '100vh',  // Full viewport height
    fontFamily: 'Arial, sans-serif',
  },
  // Left side: Sign-up form container
  formContainer: {
    width: '50%',  // Takes half of the width
    padding: '40px',
    border: '1px solid #ddd',
    borderRadius: '8px',
    backgroundColor: '#fff',
    boxSizing: 'border-box',
  },
  inputGroup: {
    marginBottom: '15px',
  },
  input: {
    width: '100%',
    padding: '10px',
    fontSize: '16px',
    borderRadius: '5px',
    border: '1px solid #ccc',
  },
  submitButton: {
    width: '100%',
    padding: '10px',
    backgroundColor: '#ff3b3f',
    color: '#fff',
    fontSize: '16px',
    borderRadius: '5px',
    cursor: 'pointer',
    border: 'none',
  },
  footer: {
    textAlign: 'center',
    marginTop: '15px',
  },
  signInLink: {
    color: '#ff3b3f',
    textDecoration: 'none',
  },
  googleSignUp: {
    textAlign: 'center',
    marginTop: '20px',
  },
  googleButton: {
    padding: '10px',
    backgroundColor: '#4285F4',
    color: '#fff',
    borderRadius: '5px',
    cursor: 'pointer',
    border: 'none',
    width: '100%',
  },

  // Right side: Text and Image
  rightContainer: {
    width: '50%',  // Takes the other half of the width
    display: 'flex',
    flexDirection: 'column',  // Stack text and image vertically
    justifyContent: 'center',  // Center content vertically
    alignItems: 'center',  // Center content horizontally
    padding: '40px',
    textAlign: 'center',
    color:'red',
  },
  imageContainer: {
    marginTop: '20px',  // Space between text and image
  },
  image: {
    maxWidth: '80%',  // Ensure the image is responsive
    height: 'auto',
    borderRadius: '8px',
  },
};

export default SignUp;
