import React from 'react';
import SignUp from './SignUp';  // Assuming SignUpForm is in the same directory

function App() {
  return (
    <div className="App">
      <SignUp/>
    </div>
  );
}

export default App;
